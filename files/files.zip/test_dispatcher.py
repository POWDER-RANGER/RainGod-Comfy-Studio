"""Tests for backend/dispatcher.py.

All cloud adapters are mocked — no real API calls made.
Ollama adapter is also mocked — no local Ollama required.
"""

from __future__ import annotations

import asyncio
import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── Env setup before any backend import ────────────────────────
os.environ.setdefault("OLLAMA_HOST", "http://localhost:11434")
# Deliberately NOT setting cloud keys — tests mock at adapter level


from backend.dispatcher import RainGodDispatcher, TaskType, DispatchResult


# ── Fixtures ────────────────────────────────────────────────────

@pytest.fixture
def dispatcher() -> RainGodDispatcher:
    d = RainGodDispatcher()
    d._adapters_initialized = True  # skip real init
    return d


def _mock_ollama(text: str = "mocked response") -> MagicMock:
    m = MagicMock()
    m.generate  = AsyncMock(return_value=text)
    m.chat      = AsyncMock(return_value=text)
    m.vision    = AsyncMock(return_value="moondream analysis")
    m.embed     = AsyncMock(return_value=[0.1, 0.2, 0.3])
    m.health    = AsyncMock(return_value=True)
    return m


def _mock_groq(text: str = "groq response") -> MagicMock:
    m = MagicMock()
    m.generate = AsyncMock(return_value=text)
    return m


def _mock_suno() -> MagicMock:
    m = MagicMock()
    m.generate = AsyncMock(return_value={
        "clip_id": "suno-abc123",
        "audio_url": "https://cdn.suno.com/test.mp3",
        "title": "Test Track",
        "duration": 30,
    })
    return m


def _mock_comfy_cloud() -> MagicMock:
    m = MagicMock()
    m.generate = AsyncMock(return_value={
        "run_id": "cc-run-001",
        "image_url": "https://comfy.cloud/outputs/test.png",
        "image_urls": ["https://comfy.cloud/outputs/test.png"],
    })
    m.generate_video = AsyncMock(return_value={
        "run_id": "cc-run-002",
        "image_url": "https://comfy.cloud/outputs/test.mp4",
    })
    return m


def _mock_gemini() -> MagicMock:
    m = MagicMock()
    m.generate = AsyncMock(return_value="gemini response")
    m.vision   = AsyncMock(return_value="dark moody atmosphere, neon blues")
    return m


def _mock_hf() -> MagicMock:
    m = MagicMock()
    m.musicgen = AsyncMock(return_value={
        "audio_url": "https://hf.co/test.wav",
        "source": "hf:musicgen-space",
    })
    m.demucs = AsyncMock(return_value={
        "stems": {"vocals": "url1", "drums": "url2", "bass": "url3", "other": "url4"}
    })
    return m


# ── TaskType enum ────────────────────────────────────────────────

class TestTaskTypeEnum:
    def test_all_values_exist(self) -> None:
        expected = {
            "llm_prompt", "llm_reasoning", "llm_tools",
            "vision_analyze", "embed",
            "image_generate", "video_generate",
            "music_generate", "audio_process", "cross_modal",
        }
        actual = {t.value for t in TaskType}
        assert expected == actual

    def test_invalid_raises(self) -> None:
        with pytest.raises(ValueError):
            TaskType("not_a_task")


# ── DispatchResult ───────────────────────────────────────────────

class TestDispatchResult:
    def test_defaults(self) -> None:
        r = DispatchResult(source="test", data={"key": "val"})
        assert r.source == "test"
        assert r.data == {"key": "val"}
        assert r.metadata == {}

    def test_metadata(self) -> None:
        r = DispatchResult(source="x", data={}, metadata={"a": 1})
        assert r.metadata["a"] == 1


# ── LLM dispatch ────────────────────────────────────────────────

class TestDispatchLLM:
    @pytest.mark.asyncio
    async def test_llm_uses_ollama_when_prefer_local(self, dispatcher) -> None:
        dispatcher._local = _mock_ollama("hello from dolphin")
        result = await dispatcher.dispatch(
            TaskType.LLM_PROMPT, {"prompt": "test"}, prefer_local=True
        )
        assert result.source == "ollama"
        assert result.data["text"] == "hello from dolphin"

    @pytest.mark.asyncio
    async def test_llm_falls_back_to_groq(self, dispatcher) -> None:
        dispatcher._local = None
        dispatcher._groq  = _mock_groq("hello from groq")
        result = await dispatcher.dispatch(
            TaskType.LLM_PROMPT, {"prompt": "test"}, prefer_local=False
        )
        assert result.source == "groq"
        assert result.data["text"] == "hello from groq"

    @pytest.mark.asyncio
    async def test_llm_raises_when_no_adapters(self, dispatcher) -> None:
        dispatcher._local      = None
        dispatcher._groq       = None
        dispatcher._openrouter = None
        with pytest.raises(RuntimeError, match="No LLM adapter"):
            await dispatcher.dispatch(TaskType.LLM_PROMPT, {"prompt": "x"})

    @pytest.mark.asyncio
    async def test_reasoning_uses_deepseek_model(self, dispatcher) -> None:
        ollama = _mock_ollama("chain of thought")
        dispatcher._local = ollama
        result = await dispatcher.dispatch(
            TaskType.LLM_REASONING, {"prompt": "why is the sky blue?"}
        )
        ollama.generate.assert_awaited_once()
        call_kwargs = ollama.generate.call_args
        assert call_kwargs.kwargs.get("model") == "deepseek-r1:1.5b" or \
               "deepseek" in str(call_kwargs)
        assert result.source == "ollama:deepseek-r1"

    @pytest.mark.asyncio
    async def test_tools_uses_qwen_model(self, dispatcher) -> None:
        ollama = _mock_ollama('{"key": "value"}')
        dispatcher._local = ollama
        result = await dispatcher.dispatch(
            TaskType.LLM_TOOLS, {"prompt": "give me JSON"}
        )
        call_kwargs = ollama.generate.call_args
        assert "qwen3:4b" in str(call_kwargs)
        assert result.source == "ollama:qwen3"


# ── Vision dispatch ──────────────────────────────────────────────

class TestDispatchVision:
    @pytest.mark.asyncio
    async def test_vision_local_moondream(self, dispatcher) -> None:
        ollama = _mock_ollama()
        dispatcher._local = ollama
        result = await dispatcher.dispatch(
            TaskType.VISION_ANALYZE,
            {"image_url": "https://example.com/img.png", "question": "describe"},
        )
        assert result.source == "ollama:moondream"
        assert result.data["text"] == "moondream analysis"

    @pytest.mark.asyncio
    async def test_vision_falls_back_to_gemini(self, dispatcher) -> None:
        dispatcher._local  = None
        dispatcher._gemini = _mock_gemini()
        result = await dispatcher.dispatch(
            TaskType.VISION_ANALYZE,
            {"image_url": "https://example.com/img.png"},
        )
        assert result.source == "gemini-flash"


# ── Embed dispatch ───────────────────────────────────────────────

class TestDispatchEmbed:
    @pytest.mark.asyncio
    async def test_embed_always_uses_ollama(self, dispatcher) -> None:
        dispatcher._local = _mock_ollama()
        result = await dispatcher.dispatch(
            TaskType.EMBED, {"text": "embed this text"}
        )
        assert result.source == "ollama:nomic-embed"
        assert isinstance(result.data["embedding"], list)
        assert len(result.data["embedding"]) == 3

    @pytest.mark.asyncio
    async def test_embed_raises_without_ollama(self, dispatcher) -> None:
        dispatcher._local = None
        with pytest.raises(RuntimeError, match="Ollama adapter required"):
            await dispatcher.dispatch(TaskType.EMBED, {"text": "x"})


# ── Image dispatch ───────────────────────────────────────────────

class TestDispatchImage:
    @pytest.mark.asyncio
    async def test_image_uses_comfy_cloud(self, dispatcher) -> None:
        dispatcher._comfy_cloud = _mock_comfy_cloud()
        result = await dispatcher.dispatch(
            TaskType.IMAGE_GENERATE,
            {"prompt": "neon city", "width": 1024, "height": 1024},
        )
        assert result.source == "comfy-cloud"
        assert result.data["image_url"].endswith(".png")

    @pytest.mark.asyncio
    async def test_image_falls_back_to_replicate(self, dispatcher) -> None:
        dispatcher._comfy_cloud = None
        rep = MagicMock()
        rep.generate_image = AsyncMock(return_value={
            "prediction_id": "rep-001",
            "image_url": "https://replicate.delivery/test.png",
        })
        dispatcher._replicate = rep
        result = await dispatcher.dispatch(
            TaskType.IMAGE_GENERATE, {"prompt": "abstract art"}
        )
        assert result.source == "replicate"


# ── Music dispatch ───────────────────────────────────────────────

class TestDispatchMusic:
    @pytest.mark.asyncio
    async def test_music_uses_suno(self, dispatcher) -> None:
        dispatcher._suno = _mock_suno()
        result = await dispatcher.dispatch(
            TaskType.MUSIC_GENERATE,
            {"prompt": "lo-fi hip hop, 120bpm, rainy night"},
        )
        assert result.source == "suno"
        assert result.data["audio_url"].endswith(".mp3")

    @pytest.mark.asyncio
    async def test_music_falls_back_to_hf(self, dispatcher) -> None:
        dispatcher._suno = None
        dispatcher._hf   = _mock_hf()
        result = await dispatcher.dispatch(
            TaskType.MUSIC_GENERATE, {"prompt": "ambient"}
        )
        assert result.source == "hf:musicgen"


# ── Audio dispatch ───────────────────────────────────────────────

class TestDispatchAudio:
    @pytest.mark.asyncio
    async def test_audio_uses_demucs(self, dispatcher) -> None:
        dispatcher._hf = _mock_hf()
        result = await dispatcher.dispatch(
            TaskType.AUDIO_PROCESS,
            {"audio_url": "https://example.com/track.mp3"},
        )
        assert result.source == "hf:demucs"
        assert "vocals" in result.data["stems"]

    @pytest.mark.asyncio
    async def test_audio_raises_without_hf(self, dispatcher) -> None:
        dispatcher._hf = None
        with pytest.raises(RuntimeError, match="HuggingFace adapter required"):
            await dispatcher.dispatch(
                TaskType.AUDIO_PROCESS, {"audio_url": "https://x.com/a.mp3"}
            )


# ── Cross-modal pipeline ─────────────────────────────────────────

class TestCrossModal:
    @pytest.mark.asyncio
    async def test_cross_modal_full_pipeline(self, dispatcher) -> None:
        # Wire all required adapters
        decomp_json = json.dumps({
            "visual_prompt":   "dark neon cityscape, rain",
            "negative_prompt": "bright, cheerful",
            "music_mood":      "lo-fi, minor key, 90bpm",
            "suno_prompt":     "melancholic lo-fi for dark cyberpunk",
        })
        ollama = _mock_ollama(decomp_json)
        dispatcher._local       = ollama
        dispatcher._comfy_cloud = _mock_comfy_cloud()
        dispatcher._gemini      = _mock_gemini()
        dispatcher._suno        = _mock_suno()

        result = await dispatcher.dispatch(
            TaskType.CROSS_MODAL,
            {"prompt": "dark cyberpunk rain scene, melancholic"},
        )

        assert result.source == "cross-modal-pipeline"
        assert "image" in result.data
        assert "music" in result.data
        assert "decomposition" in result.data
        assert "pipeline_sources" in result.data

    @pytest.mark.asyncio
    async def test_cross_modal_handles_bad_json_gracefully(self, dispatcher) -> None:
        """If LLM returns non-JSON, pipeline should still complete with fallbacks."""
        dispatcher._local       = _mock_ollama("not valid json at all")
        dispatcher._comfy_cloud = _mock_comfy_cloud()
        dispatcher._suno        = _mock_suno()

        # Should not raise — falls back to defaults
        result = await dispatcher.dispatch(
            TaskType.CROSS_MODAL,
            {"prompt": "test prompt"},
        )
        assert result.source == "cross-modal-pipeline"

    @pytest.mark.asyncio
    async def test_cross_modal_skips_vision_without_image_url(self, dispatcher) -> None:
        """If image generation returns no URL, vision step is skipped gracefully."""
        ollama = _mock_ollama('{"visual_prompt":"x","negative_prompt":"","music_mood":"ambient","suno_prompt":"ambient"}')
        dispatcher._local = ollama

        no_url_comfy = MagicMock()
        no_url_comfy.generate = AsyncMock(return_value={
            "run_id": "cc-001", "image_url": None, "image_urls": []
        })
        dispatcher._comfy_cloud = no_url_comfy
        dispatcher._suno        = _mock_suno()

        result = await dispatcher.dispatch(
            TaskType.CROSS_MODAL, {"prompt": "abstract"}
        )
        # vision_analysis should be None when no image URL
        assert result.data.get("vision_analysis") is None


# ── Status ───────────────────────────────────────────────────────

class TestDispatcherStatus:
    def test_status_reflects_loaded_adapters(self, dispatcher) -> None:
        dispatcher._local       = _mock_ollama()
        dispatcher._groq        = _mock_groq()
        dispatcher._comfy_cloud = None
        dispatcher._suno        = _mock_suno()

        status = dispatcher.status()
        assert status["local_ollama"] is True
        assert status["groq"]         is True
        assert status["comfy_cloud"]  is False
        assert status["suno"]         is True

    def test_status_all_false_when_uninitialized(self) -> None:
        d = RainGodDispatcher()
        d._adapters_initialized = True  # skip real init, all remain None
        status = d.status()
        assert all(v is False for v in status.values())
