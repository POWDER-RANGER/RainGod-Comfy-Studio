"""Shared pytest fixtures for RainGod Comfy Studio tests."""

from __future__ import annotations

import os
import pytest

# ── Set all env vars before any backend import ──────────────────
os.environ.setdefault("OLLAMA_HOST",           "http://localhost:11434")
os.environ.setdefault("ALLOWED_ORIGINS",       "http://localhost:3000")
os.environ.setdefault("COMFYUI_HOST",          "127.0.0.1")
os.environ.setdefault("COMFYUI_PORT",          "18188")
os.environ.setdefault("GROQ_API_KEY",          "test-groq")
os.environ.setdefault("GEMINI_API_KEY",        "test-gemini")
os.environ.setdefault("SUNO_API_KEY",          "test-suno")
os.environ.setdefault("COMFY_API_KEY",         "test-comfy")
os.environ.setdefault("OPENROUTER_API_KEY",    "test-openrouter")
os.environ.setdefault("HF_TOKEN",              "test-hf")
os.environ.setdefault("REPLICATE_API_KEY",     "test-replicate")


@pytest.fixture(scope="session")
def anyio_backend():
    return "asyncio"
