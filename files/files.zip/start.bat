@echo off
REM ============================================================
REM RainGod Comfy Studio — Windows Startup
REM Run from repo root: scripts\start.bat
REM ============================================================

setlocal EnableDelayedExpansion

set "ROOT=%~dp0.."
set "COMFYUI_DIR=%ROOT%\ComfyUI"
set "VENV_DIR=%ROOT%\venv"
set "LOG_DIR=%ROOT%\logs"
set "PID_DIR=%ROOT%\.pids"
set "BACKEND_PORT=8000"
set "COMFYUI_PORT=8188"

REM ── Colors via ANSI (Windows 10+) ───────────────────────────
for /f %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "GREEN=%ESC%[32m"
set "CYAN=%ESC%[36m"
set "YELLOW=%ESC%[33m"
set "RED=%ESC%[31m"
set "NC=%ESC%[0m"

echo.
echo %CYAN%===================================================%NC%
echo %CYAN%   RainGod Comfy Studio — Starting Up%NC%
echo %CYAN%===================================================%NC%
echo.

REM ── Create dirs ─────────────────────────────────────────────
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
if not exist "%PID_DIR%" mkdir "%PID_DIR%"
if not exist "%ROOT%\outputs" mkdir "%ROOT%\outputs"
if not exist "%ROOT%\temp"    mkdir "%ROOT%\temp"
if not exist "%ROOT%\cache"   mkdir "%ROOT%\cache"

REM ── Load .env if present ────────────────────────────────────
if exist "%ROOT%\.env" (
    echo %CYAN%[INFO]%NC%  Loading .env ...
    for /f "usebackq tokens=1,2 delims==" %%a in ("%ROOT%\.env") do (
        set "line=%%a"
        if not "!line:~0,1!"=="#" (
            if not "%%b"=="" (
                set "%%a=%%b"
            )
        )
    )
    echo %GREEN%[OK]%NC%    .env loaded
) else (
    echo %YELLOW%[WARN]%NC%  No .env found — using system env vars
    echo        Copy .env.example to .env and fill in your API keys
)

REM ── Check Python ────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo %RED%[ERR]%NC%   Python not found. Install from python.org
    pause & exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set "PY_VER=%%v"
echo %GREEN%[OK]%NC%    Python %PY_VER% found

REM ── Activate venv or warn ───────────────────────────────────
if exist "%VENV_DIR%\Scripts\activate.bat" (
    call "%VENV_DIR%\Scripts\activate.bat"
    echo %GREEN%[OK]%NC%    Virtualenv activated
) else (
    echo %YELLOW%[WARN]%NC%  No venv found at %VENV_DIR%
    echo        Run: python -m venv venv ^&^& venv\Scripts\activate ^&^& pip install -r requirements.txt
)

REM ── Check uvicorn ───────────────────────────────────────────
uvicorn --version >nul 2>&1
if errorlevel 1 (
    echo %RED%[ERR]%NC%   uvicorn not found. Run: pip install -r requirements.txt
    pause & exit /b 1
)

REM ── Start ComfyUI (optional) ────────────────────────────────
if exist "%COMFYUI_DIR%\main.py" (
    echo %CYAN%[INFO]%NC%  Starting ComfyUI on port %COMFYUI_PORT% ...
    start "RainGod-ComfyUI" /min cmd /c ^
        "cd /d "%COMFYUI_DIR%" && python main.py --listen 127.0.0.1 --port %COMFYUI_PORT% > "%LOG_DIR%\comfyui.log" 2>&1"
    echo %GREEN%[OK]%NC%    ComfyUI starting — log: logs\comfyui.log
    timeout /t 5 /nobreak >nul
) else (
    echo %YELLOW%[WARN]%NC%  ComfyUI not found at %COMFYUI_DIR% — skipping
    echo        Image gen will route to Comfy Cloud / Replicate
)

REM ── Start RainGod Backend ───────────────────────────────────
echo %CYAN%[INFO]%NC%  Starting RainGod backend on port %BACKEND_PORT% ...

start "RainGod-Backend" /min cmd /c ^
    "cd /d "%ROOT%" && uvicorn backend.main:app --host 0.0.0.0 --port %BACKEND_PORT% --reload > "%LOG_DIR%\backend.log" 2>&1"

REM Save approximate PID via WMIC (best effort on Windows)
timeout /t 3 /nobreak >nul
for /f "tokens=2" %%p in ('wmic process where "name='cmd.exe' and commandline like '%%backend.main%%'" get processid /value 2^>nul ^| find "="') do (
    echo %%p > "%PID_DIR%\backend.pid"
)

echo %GREEN%[OK]%NC%    Backend starting — log: logs\backend.log

REM ── Wait for backend health ──────────────────────────────────
echo %CYAN%[INFO]%NC%  Waiting for backend health check ...
set "ATTEMPTS=0"
:HEALTH_LOOP
timeout /t 2 /nobreak >nul
set /a ATTEMPTS+=1
curl -sf http://localhost:%BACKEND_PORT%/health >nul 2>&1
if not errorlevel 1 (
    echo %GREEN%[OK]%NC%    Backend is healthy
    goto READY
)
if %ATTEMPTS% geq 20 (
    echo %RED%[ERR]%NC%   Backend did not start within 40s
    echo        Check logs\backend.log for errors
    goto SHOW_URLS
)
goto HEALTH_LOOP

:READY
REM ── Validate API keys (quick) ────────────────────────────────
echo %CYAN%[INFO]%NC%  Checking fleet status ...
curl -sf http://localhost:%BACKEND_PORT%/dispatch/status > "%LOG_DIR%\fleet_status.json" 2>&1
if not errorlevel 1 (
    echo %GREEN%[OK]%NC%    Fleet status retrieved — see logs\fleet_status.json
)

:SHOW_URLS
echo.
echo %CYAN%===================================================%NC%
echo %GREEN%   RainGod Comfy Studio is running%NC%
echo %CYAN%===================================================%NC%
echo.
echo   Studio UI:    http://localhost:%BACKEND_PORT%/
echo   API Docs:     http://localhost:%BACKEND_PORT%/api/docs
echo   Dispatch:     http://localhost:%BACKEND_PORT%/dispatch/status
echo   ComfyUI:      http://localhost:%COMFYUI_PORT%
echo.
echo   Logs:
echo     Backend:    logs\backend.log
echo     ComfyUI:    logs\comfyui.log
echo.
echo   To stop:      scripts\stop.bat
echo   API Keys:     scripts\deploy_api_keys.ps1
echo   Validate:     python scripts\validate_keys.py
echo.

REM ── Open browser ────────────────────────────────────────────
set /p "OPEN=Open Studio in browser? (y/n): "
if /i "%OPEN%"=="y" start http://localhost:%BACKEND_PORT%/

echo.
echo %CYAN%[INFO]%NC%  Press any key to tail backend log (Ctrl+C to exit log view)
pause >nul
type "%LOG_DIR%\backend.log"
echo.
echo %YELLOW%[INFO]%NC%  Services are still running in background windows.
echo        Close those windows or run scripts\stop.bat to shut down.
pause
endlocal
