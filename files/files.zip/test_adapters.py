"""Tests for all local and cloud adapters.

Uses httpx.MockTransport — zero real network calls.
"""

from __future__ import annotations

import base64
import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import httpx

os.environ.setdefault("GROQ_API_KEY",       "test-groq-key")
os.environ.setdefault("GEMINI_API_KEY",     "test-gemini-key")
os.environ.setdefault("SUNO_API_KEY",       "test-suno-key")
os.environ.setdefault("COMFY_API_KEY",      "test-comfy-key")
os.environ.setdefault("OPENROUTER_API_KEY", "test-or-key")
os.environ.setdefault("HF_TOKEN",           "test-hf-token")
os.environ.setdefault("REPLICATE_API_KEY",  "test-rep-key")


# ── Helpers ─────────────────────────────────────────────────────

def _json_response(data: dict, status: int = 200) -> httpx.Response:
    return httpx.Response(status, json=data)


def _mock_client(responses: list[httpx.Response]) -> MagicMock:
    """Return a mock httpx.AsyncClient that yields responses in order."""
    client = MagicMock()
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__  = AsyncMock(return_value=None)

    # Make get/post return responses in sequence
    _resp_iter = iter(responses)

    async def _request(*args, **kwargs) -> httpx.Response:
        return next(_resp_iter)

    client.get  = AsyncMock(side_effect=_request)
    client.post = AsyncMock(side_effect=_request)
    client.aclose = AsyncMock()
    return client


# ════════════════════════════════════════════════════════════════
# OllamaAdapter
# ════════════════════════════════════════════════════════════════

class TestOllamaAdapter:
    def _make(self) -> "OllamaAdapter":
        from backend.local_adapters.ollama_adapter import OllamaAdapter
        return OllamaAdapter(base_url="http://localhost:11434")

    @pytest.mark.asyncio
    async def test_generate_returns_response_text(self) -> None:
        adapter = self._make()
        mock_resp = _json_response({"response": "hello from dolphin"})
        adapter._client.post = AsyncMock(return_value=mock_resp)
        result = await adapter.generate("tell me something")
        assert result == "hello from dolphin"

    @pytest.mark.asyncio
    async def test_generate_passes_model(self) -> None:
        adapter = self._make()
        mock_resp = _json_response({"response": "ok"})
        adapter._client.post = AsyncMock(return_value=mock_resp)
        await adapter.generate("test", model="qwen3:4b")
        payload = adapter._client.post.call_args.kwargs.get("json") or \
                  adapter._client.post.call_args.args[1] if len(adapter._client.post.call_args.args) > 1 else {}
        # Model should be in the post payload
        post_call = adapter._client.post.call_args
        assert "qwen3:4b" in str(post_call)

    @pytest.mark.asyncio
    async def test_embed_returns_list(self) -> None:
        adapter = self._make()
        mock_resp = _json_response({"embeddings": [[0.1, 0.2, 0.3, 0.4]]})
        adapter._client.post = AsyncMock(return_value=mock_resp)
        result = await adapter.embed("some text")
        assert isinstance(result, list)
        assert len(result) == 4
        assert result[0] == pytest.approx(0.1)

    @pytest.mark.asyncio
    async def test_health_true_on_200(self) -> None:
        adapter = self._make()
        adapter._client.get = AsyncMock(return_value=httpx.Response(200, json={"models": []}))
        assert await adapter.health() is True

    @pytest.mark.asyncio
    async def test_health_false_on_connection_error(self) -> None:
        adapter = self._make()
        adapter._client.get = AsyncMock(side_effect=httpx.ConnectError("refused"))
        assert await adapter.health() is False

    @pytest.mark.asyncio
    async def test_list_models(self) -> None:
        adapter = self._make()
        adapter._client.get = AsyncMock(return_value=_json_response({
            "models": [{"name": "dolphin-llama3:8b"}, {"name": "qwen3:4b"}]
        }))
        models = await adapter.list_models()
        assert "dolphin-llama3:8b" in models
        assert "qwen3:4b" in models


# ════════════════════════════════════════════════════════════════
# GroqAdapter
# ════════════════════════════════════════════════════════════════

class TestGroqAdapter:
    def _make(self) -> "GroqAdapter":
        from backend.cloud_adapters.groq_adapter import GroqAdapter
        return GroqAdapter()

    @pytest.mark.asyncio
    async def test_generate_returns_content(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "choices": [{"message": {"content": "groq says hello"}}]
        }))
        result = await adapter.generate("test prompt")
        assert result == "groq says hello"

    @pytest.mark.asyncio
    async def test_system_prompt_prepended(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "choices": [{"message": {"content": "ok"}}]
        }))
        await adapter.generate("user msg", system="you are a helpful assistant")
        payload = adapter._client.post.call_args.kwargs.get("json", {})
        messages = payload.get("messages", [])
        assert messages[0]["role"] == "system"
        assert "helpful" in messages[0]["content"]

    @pytest.mark.asyncio
    async def test_http_error_propagates(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=httpx.Response(429, json={"error": "rate limited"}))
        with pytest.raises(httpx.HTTPStatusError):
            await adapter.generate("test")


# ════════════════════════════════════════════════════════════════
# GeminiAdapter
# ════════════════════════════════════════════════════════════════

class TestGeminiAdapter:
    def _make(self) -> "GeminiAdapter":
        from backend.cloud_adapters.gemini_adapter import GeminiAdapter
        return GeminiAdapter()

    @pytest.mark.asyncio
    async def test_generate_returns_text(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "candidates": [{"content": {"parts": [{"text": "gemini response"}]}}]
        }))
        result = await adapter.generate("describe the universe")
        assert result == "gemini response"

    @pytest.mark.asyncio
    async def test_vision_with_b64_image(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "candidates": [{"content": {"parts": [{"text": "dark moody scene"}]}}]
        }))
        fake_b64 = base64.b64encode(b"fake_image_bytes").decode()
        result = await adapter.vision(prompt="describe", image_b64=fake_b64)
        assert result == "dark moody scene"
        # Verify image was included in request
        payload = adapter._client.post.call_args.kwargs.get("json", {})
        parts = payload["contents"][0]["parts"]
        assert any("inline_data" in p for p in parts)


# ════════════════════════════════════════════════════════════════
# SunoAdapter
# ════════════════════════════════════════════════════════════════

class TestSunoAdapter:
    def _make(self) -> "SunoAdapter":
        from backend.cloud_adapters.suno_adapter import SunoAdapter
        return SunoAdapter()

    @pytest.mark.asyncio
    async def test_generate_polls_until_complete(self) -> None:
        adapter = self._make()

        submit_resp = _json_response({"clips": [{"id": "clip-xyz"}]})
        pending_resp = _json_response({"id": "clip-xyz", "status": "running"})
        complete_resp = _json_response({
            "id": "clip-xyz", "status": "complete",
            "audio_url": "https://suno.com/clip-xyz.mp3",
            "title": "Test Track", "duration": 30, "tags": "lo-fi",
        })

        post_calls = iter([submit_resp])
        get_calls  = iter([pending_resp, complete_resp])

        adapter._client.post = AsyncMock(side_effect=lambda *a, **k: next(post_calls))
        adapter._client.get  = AsyncMock(side_effect=lambda *a, **k: next(get_calls))

        result = await adapter.generate(
            {"prompt": "lo-fi rain", "duration": 30},
            poll_interval=0.01,
        )
        assert result["clip_id"] == "clip-xyz"
        assert result["audio_url"].endswith(".mp3")

    @pytest.mark.asyncio
    async def test_generate_raises_on_empty_clips(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({"clips": []}))
        with pytest.raises(RuntimeError, match="no clip IDs"):
            await adapter.generate({"prompt": "test"}, poll_interval=0.01)

    @pytest.mark.asyncio
    async def test_generate_times_out(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "clips": [{"id": "clip-slow"}]
        }))
        adapter._client.get = AsyncMock(return_value=_json_response({
            "id": "clip-slow", "status": "running"
        }))
        with pytest.raises(TimeoutError):
            await adapter.generate(
                {"prompt": "slow"},
                poll_interval=0.01,
                max_wait=0.05,  # times out immediately
            )


# ════════════════════════════════════════════════════════════════
# ComfyCloudAdapter
# ════════════════════════════════════════════════════════════════

class TestComfyCloudAdapter:
    def _make(self) -> "ComfyCloudAdapter":
        from backend.cloud_adapters.comfy_cloud_adapter import ComfyCloudAdapter
        return ComfyCloudAdapter()

    @pytest.mark.asyncio
    async def test_generate_polls_until_completed(self) -> None:
        adapter = self._make()

        submit_resp  = _json_response({"run_id": "run-001"})
        running_resp = _json_response({"run_id": "run-001", "status": "running", "outputs": {}})
        done_resp    = _json_response({
            "run_id": "run-001", "status": "completed",
            "outputs": {
                "7": {"images": [{"url": "https://comfy.cloud/out.png"}]}
            },
        })

        post_calls = iter([submit_resp])
        get_calls  = iter([running_resp, done_resp])

        adapter._client.post = AsyncMock(side_effect=lambda *a, **k: next(post_calls))
        adapter._client.get  = AsyncMock(side_effect=lambda *a, **k: next(get_calls))

        result = await adapter.generate(
            {"prompt": "neon city", "width": 1024, "height": 1024},
            poll_interval=0.01,
        )
        assert result["run_id"] == "run-001"
        assert result["image_url"] == "https://comfy.cloud/out.png"

    @pytest.mark.asyncio
    async def test_generate_raises_on_failed_run(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({"run_id": "r-fail"}))
        adapter._client.get  = AsyncMock(return_value=_json_response({
            "run_id": "r-fail", "status": "failed", "error": "OOM"
        }))
        with pytest.raises(RuntimeError, match="failed"):
            await adapter.generate({"prompt": "x"}, poll_interval=0.01)


# ════════════════════════════════════════════════════════════════
# OpenRouterAdapter
# ════════════════════════════════════════════════════════════════

class TestOpenRouterAdapter:
    def _make(self) -> "OpenRouterAdapter":
        from backend.cloud_adapters.openrouter_adapter import OpenRouterAdapter
        return OpenRouterAdapter()

    @pytest.mark.asyncio
    async def test_generate_returns_content(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "choices": [{"message": {"content": "openrouter response"}}]
        }))
        result = await adapter.generate("test")
        assert result == "openrouter response"

    @pytest.mark.asyncio
    async def test_referer_header_set(self) -> None:
        from backend.cloud_adapters.openrouter_adapter import OpenRouterAdapter
        adapter = OpenRouterAdapter()
        # Headers set on client construction
        assert "HTTP-Referer" in adapter._client.headers
        assert "X-Title" in adapter._client.headers


# ════════════════════════════════════════════════════════════════
# HuggingFaceAdapter
# ════════════════════════════════════════════════════════════════

class TestHuggingFaceAdapter:
    def _make(self) -> "HuggingFaceAdapter":
        from backend.cloud_adapters.hf_adapter import HuggingFaceAdapter
        return HuggingFaceAdapter()

    @pytest.mark.asyncio
    async def test_musicgen_returns_audio_url(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "data": ["https://hf.co/audio/test.wav"]
        }))
        result = await adapter.musicgen({"prompt": "ambient", "duration": 10})
        assert result["audio_url"] == "https://hf.co/audio/test.wav"
        assert result["source"] == "hf:musicgen-space"

    @pytest.mark.asyncio
    async def test_demucs_returns_four_stems(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "data": ["url_vocals", "url_drums", "url_bass", "url_other"]
        }))
        result = await adapter.demucs({"audio_url": "https://example.com/track.mp3"})
        stems = result["stems"]
        assert stems["vocals"] == "url_vocals"
        assert stems["drums"]  == "url_drums"
        assert stems["bass"]   == "url_bass"
        assert stems["other"]  == "url_other"

    @pytest.mark.asyncio
    async def test_demucs_raises_without_audio_url(self) -> None:
        adapter = self._make()
        with pytest.raises(ValueError, match="audio_url required"):
            await adapter.demucs({})


# ════════════════════════════════════════════════════════════════
# ReplicateAdapter
# ════════════════════════════════════════════════════════════════

class TestReplicateAdapter:
    def _make(self) -> "ReplicateAdapter":
        from backend.cloud_adapters.replicate_adapter import ReplicateAdapter
        return ReplicateAdapter()

    @pytest.mark.asyncio
    async def test_generate_image_polls_until_succeeded(self) -> None:
        adapter = self._make()

        submit_resp    = _json_response({"id": "pred-abc", "status": "starting"})
        processing_resp = _json_response({"id": "pred-abc", "status": "processing"})
        succeeded_resp  = _json_response({
            "id": "pred-abc", "status": "succeeded",
            "output": ["https://replicate.delivery/test.png"],
        })

        post_calls = iter([submit_resp])
        get_calls  = iter([processing_resp, succeeded_resp])

        adapter._client.post = AsyncMock(side_effect=lambda *a, **k: next(post_calls))
        adapter._client.get  = AsyncMock(side_effect=lambda *a, **k: next(get_calls))

        result = await adapter.generate_image(
            {"prompt": "abstract art", "width": 512, "height": 512},
            poll_interval=0.01,
        )
        assert result["prediction_id"] == "pred-abc"
        assert result["image_url"] == "https://replicate.delivery/test.png"
        assert result["source"] == "replicate"

    @pytest.mark.asyncio
    async def test_generate_image_raises_on_failed(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "id": "pred-fail", "status": "starting"
        }))
        adapter._client.get = AsyncMock(return_value=_json_response({
            "id": "pred-fail", "status": "failed", "error": "GPU OOM"
        }))
        with pytest.raises(RuntimeError, match="failed"):
            await adapter.generate_image({"prompt": "x"}, poll_interval=0.01)

    @pytest.mark.asyncio
    async def test_generate_image_times_out(self) -> None:
        adapter = self._make()
        adapter._client.post = AsyncMock(return_value=_json_response({
            "id": "pred-slow", "status": "starting"
        }))
        adapter._client.get = AsyncMock(return_value=_json_response({
            "id": "pred-slow", "status": "processing"
        }))
        with pytest.raises(TimeoutError):
            await adapter.generate_image(
                {"prompt": "x"},
                poll_interval=0.01,
                max_wait=0.05,
            )

    def test_version_ids_are_non_placeholder(self) -> None:
        """Ensure no version ID contains 'placeholder' (caught regression)."""
        from backend.cloud_adapters import replicate_adapter as ra
        for attr in ("SDXL_VERSION", "SDXL_LIGHTNING_VERSION",
                     "ANIMATEDIFF_VERSION", "FLUX_SCHNELL_VERSION"):
            val = getattr(ra, attr)
            assert "placeholder" not in val.lower(), \
                f"{attr} still contains placeholder: {val}"
            assert len(val) >= 32, f"{attr} too short to be a real hash: {val}"
