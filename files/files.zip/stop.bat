@echo off
REM ============================================================
REM RainGod Comfy Studio — Stop All Services
REM ============================================================

for /f %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "GREEN=%ESC%[32m"
set "YELLOW=%ESC%[33m"
set "CYAN=%ESC%[36m"
set "NC=%ESC%[0m"

echo %CYAN%[INFO]%NC%  Stopping RainGod services ...

REM Kill by window title (set by start.bat)
taskkill /fi "windowtitle eq RainGod-Backend*" /f >nul 2>&1
taskkill /fi "windowtitle eq RainGod-ComfyUI*" /f >nul 2>&1

REM Kill by port (belt-and-suspenders)
for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":8000 " ^| findstr "LISTENING"') do (
    taskkill /pid %%p /f >nul 2>&1
)
for /f "tokens=5" %%p in ('netstat -ano 2^>nul ^| findstr ":8188 " ^| findstr "LISTENING"') do (
    taskkill /pid %%p /f >nul 2>&1
)

echo %GREEN%[OK]%NC%    Services stopped
if exist ".pids" rd /s /q ".pids"
